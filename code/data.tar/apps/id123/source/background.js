console.log("from background!");




/*
///DATASTORE

db=pine.dataStore('conf');

var doc = { hello: 'world'
               , n: 5
               , today: new Date()
               , nedbIsAwesome: true
               , notthere: null
               , notToBeSaved: undefined  // Will not be saved
               , fruits: [ 'apple', 'orange', 'pear' ]
               , infos: { name: 'nedb' }
               };

db.insert(doc, function (err, newDoc) {   
    console.log('inserted!',err);
});

db.find({ }, function (err, docs) {
    console.log(docs);
  });
*/




///////////////////