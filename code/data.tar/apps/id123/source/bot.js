module.exports=function(){
    console.log("Hi! I'm a bot, but don't be scared of me pls ;)")
}